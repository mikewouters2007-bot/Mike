const {
    SlashCommandBuilder,
    EmbedBuilder
} = require('discord.js');

const db = require('../db');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('stats')
        .setDescription('Bekijk jouw stats'),

    async execute(interaction) {

        const gebruiker = interaction.user.tag;

        const rows = db.prepare(`
            SELECT * FROM logs
            WHERE gebruiker = ?
        `).all(gebruiker);

        const totaal = rows.length;

        const witwas = rows
            .filter(r => r.type === 'witwas')
            .length;

        const ammo = rows
            .filter(r => r.type === 'ammo')
            .length;

        const wapens = rows
            .filter(r => r.type === 'wapens')
            .length;

        const inkoop = rows
            .filter(r => r.type === 'inkoop')
            .length;

        const embed = new EmbedBuilder()
            .setTitle('📊 Jouw Stats')
            .addFields(
                { name: 'Totaal', value: String(totaal), inline: true },
                { name: 'Witwas', value: String(witwas), inline: true },
                { name: 'Ammo', value: String(ammo), inline: true },
                { name: 'Wapens', value: String(wapens), inline: true },
                { name: 'Inkoop', value: String(inkoop), inline: true }
            )
            .setColor('DarkRed');

        await interaction.reply({
            embeds: [embed]
        });
    }
};