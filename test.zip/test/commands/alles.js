const {
    SlashCommandBuilder
} = require('discord.js');

const db = require('../db');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('week')
        .setDescription('Compact week overzicht'),

    async execute(interaction) {

        const roleName = process.env.COUNCIL_ROLE;

        const hasRole = interaction.member.roles.cache
            .some(r => r.name === roleName);

        if (!hasRole) {
            return interaction.reply({
                content: 'Geen permissie.',
                ephemeral: true
            });
        }

        const rows = db.prepare(`
            SELECT 
                naam,

                COUNT(CASE WHEN type = 'witwassen' THEN 1 END) as witwassen_aantal,
                COALESCE(SUM(CASE WHEN type = 'witwassen' THEN bedrag END), 0) as witwassen_totaal,

                COUNT(CASE WHEN type = 'ammo' THEN 1 END) as ammo_aantal,
                COALESCE(SUM(CASE WHEN type = 'ammo' THEN bedrag END), 0) as ammo_totaal,

                COUNT(CASE WHEN type = 'wapens' THEN 1 END) as wapens_aantal,
                COALESCE(SUM(CASE WHEN type = 'wapens' THEN bedrag END), 0) as wapens_totaal,

                COALESCE(SUM(inkoop), 0) as inkoop_totaal

            FROM logs
            WHERE created_at >= datetime('now', '-7 day')
            GROUP BY naam
            ORDER BY witwassen_totaal DESC
        `).all();

        if (!rows.length) {
            return interaction.reply('Geen registraties deze week.');
        }

        const overzicht = rows.map(r => `
👤 ${r.naam}

💰 ${r.witwassen_aantal}x | €${Number(r.witwassen_totaal).toLocaleString('nl-NL')}

🔫 ${r.ammo_aantal}x | €${Number(r.ammo_totaal).toLocaleString('nl-NL')}

🪖 ${r.wapens_aantal}x | €${Number(r.wapens_totaal).toLocaleString('nl-NL')}

📦 €${Number(r.inkoop_totaal).toLocaleString('nl-NL')}
        `).join('\n');

        await interaction.reply({
            content: `📅 Week Overzicht\n${overzicht}`
        });
    }
};